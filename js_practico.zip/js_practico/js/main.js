function saludo() {
    alert ("!Bienvenido¡");
}


function circulo(){
    var figura = document.getElementById("figura");
    figura.classList.toggle("circulo");
}


function rectangulo(){
    var figura = document.querySelector("#figura");
    figura.classList.toggle("rectangulo");
}


function movetop(){
    var figura = document.querySelector("#figura");
    figura.classList.toggle("movetop");
}

function bottom(){
    var figura = document.querySelector("#figura");
    figura.classList.toggle("bottom");
}

function left(){
    var figura = document.querySelector("#figura");
    figura.classList.toggle("left");
}

function right(){
    var figura = document.querySelector("#figura");
    figura.classList.toggle("right");
}

function diagonal(){
    var figura = document.querySelector("#figura");
    figura.classList.toggle("diagonal");
}

function imagen(){
    var figura = document.querySelector("#figura");
    figura.classList.toggle("imagen");
}


function rombo() {
  var figura = document.getElementById("figura");
  figura.classList.toggle("rombo");
}







//algoritmos

//suma

function suma(){
    var A = 0;
    var B = 0;
    var suma = 0;

    alert("Algoritmo que suma dos valores ingresados por el usuario")

    A = parseInt(prompt("Ingrese el primer valor: "));
    B = parseInt(prompt("Ingrese el segundo valor: "));

    suma = A+B;

    alert("El resultado de la suma es:" + suma);
}

//inversion
function inversion(){



    alert("Algoritmo de inversion de capital")


    var capital =  prompt("Ingrese la cantidad de inversion:");
    var tasa = 0.017; 
    var años = prompt("Ingrese el número de años de inversión:");

    años = parseInt(años);
    capital = parseInt(capital);

    var meses = años * 12;

    var ganancia = capital * ((1 + tasa, meses) - 1);
    var total = capital + ganancia;

    alert("La ganancia es de: " + ganancia); 
    alert("El total es: " + total);

}


//area de Triangulo
function areatriangulo(){


var base = prompt("Ingrese la base del triángulo:");
var altura = prompt("Ingrese la altura del triángulo:");


base = parseFloat(base);
altura = parseFloat(altura);


var area = (base * altura) / 2;

alert ("El area del triangulo es de: " + area);
}

//descuento

function descuento(){
   
const precio = 4500;
var kilos = prompt("Ingrese la cantidad de kilos de manzanas que está comprando:");

kilos = parseFloat(kilos);

var precioDescuento = precio * kilos;

var descuento = 0;
if (kilos <= 2) {
  descuento = precioDescuento * 0;
} else if (kilos >= 3 && kilos <= 5) {

    descuento = precioDescuento * 0.10;
  } else if (kilos >= 6 && kilos <= 10) {
    
    descuento = precioDescuento * 0.15;
  } else {
   
    descuento = precioDescuento * 0.15;
  }

  alert ("El descuento es de: " + descuento);

}

//promedio
function promedio(){
   
var calificaciones = 0;
for (var i = 1; i <= 7; i++) {
  var calificacion = prompt("Ingrese la calificación #" + i + ":");

  calificaciones = parseFloat(calificacion);
}

var sumaCalificaciones = 0;
for (var i = 0; i < calificaciones; i++) {
  sumaCalificaciones += calificaciones[i];
}
var promedio = sumaCalificaciones / calificaciones;


if (promedio >= 6.2) {
  alert("El alumno ha aprobado.");
} else {
  alert("El alumno ha reprobado.");
}

}


//operaciones

function operaciones(){
  var A =0;
  var B =0;
  var suma =0;

  alert("Algoritmo que suma dos valores ingresados");
  A =parseInt(prompt("Ingrese el primer valor a sumar"));
  B =parseInt(prompt("Ingrese el segundo valor a sumar"));
  suma = A + B;
  alert("El resultado de la suma es: "+ suma);

  alert("Algoritmo que resta dos valores ingresados");
  A =parseInt(prompt("Ingrese el primer valor a restar"));
  B =parseInt(prompt("Ingrese el segundo valor a restar"));
  resta = A - B;
  alert("El resultado de la resta es: "+ resta);

  alert("Algoritmo que multiplica dos valores ingresados");
  A =parseInt(prompt("Ingrese el primer valor a multiplicar"));
  B =parseInt(prompt("Ingrese el segundo valor a multiplicar"));
  multiplicacion = A * B;
  alert("El resultado de la multiplicacion es: "+ multiplicacion);

  alert("Algoritmo que divide dos valores ingresados");
  A =parseInt(prompt("Ingrese el primer valor a dividir"));
  B =parseInt(prompt("Ingrese el segundo valor a dividir"));
  divicion = A / B;
  alert("El resultado de la resta es: "+ divicion);
}

